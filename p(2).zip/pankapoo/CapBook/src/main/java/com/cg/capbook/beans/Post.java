package com.cg.capbook.beans;

public class Post {
	private String postContent;
	private Photo photo;
}
