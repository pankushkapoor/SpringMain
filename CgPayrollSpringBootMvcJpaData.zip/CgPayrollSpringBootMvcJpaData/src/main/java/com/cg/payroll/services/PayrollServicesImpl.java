package com.cg.payroll.services;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

@Component(value="payrollServices")
public class PayrollServicesImpl implements PayrollServices{
	@Autowired
	private AssociateDAO associateDAO;

	@Override
	public Associate acceptAssociateDetails(Associate associate)
	{
		//Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new BankDetails((int)accountNumber, bankName, ifscCode),new Salary(basicSalary, epf, companyPf));
		return associateDAO.save(associate);
		//return associate.getAssociateId();
	}
	@Override
	public int calculateNetSalary(int associateId)
			throws AssociateDetailsNotFoundException
	{	Associate associate=null;
	associate = getAssociateDetails(associateId);

	associate.setSalary(new Salary(associate.getSalary().getBasicSalary()));
	System.out.println("Basic Salary : "+associate.getSalary().getBasicSalary());
	System.out.println("Personal Allowance : "+associate.getSalary().getPersonalAllowance());
	System.out.println("HRA : "+associate.getSalary().getHra());
	System.out.println("OtherAllowance : "+associate.getSalary().getOtherAllowance());
	System.out.println("Conveyence Allowance : "+associate.getSalary().getConveyenceAllowance());
	System.out.println("Gross Salary : "+associate.getSalary().getGrossSalary());

	associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary());

	int salaryPerAnnum=(associate.getSalary().getGrossSalary()*12);
	if(salaryPerAnnum<=250000){
		associate.getSalary().setMonthlyTax(0);
	}
	else if(salaryPerAnnum>250000 && salaryPerAnnum<=500000)
		associate.getSalary().setMonthlyTax((10*(associate.getSalary().getGrossSalary()-250000))/(100*12));
	else if(salaryPerAnnum>500000 && salaryPerAnnum<=1000000){
		int tillfive=25000;
		int tillten=(20*(1000000-associate.getSalary().getBasicSalary()))/100;
		associate.getSalary().setMonthlyTax((tillfive+tillten)/12);
	}
	associate.getSalary().setNetSalary((associate.getSalary().getBasicSalary())-(associate.getSalary().getMonthlyTax()));
	associateDAO.save(associate);
	return associate.getSalary().getNetSalary();
	}
	@Override
	public Associate getAssociateDetails(int associateId)
			throws AssociateDetailsNotFoundException {
		Associate associate = null;

		associate = associateDAO.findById(associateId).get();
		if(associate==null) throw new AssociateDetailsNotFoundException("Associate Details not found");
		return associate;
	}
	@Override
	public ArrayList<Associate> getAllAssociateDetails(){

		return (ArrayList<Associate>) associateDAO.findAll();
	}
	@Override
	public ArrayList<Associate> findFewAssociate(int yearlyInvestmentUnder80C) {
		ArrayList<Associate> associateList = associateDAO.findFewAssociate(yearlyInvestmentUnder80C);
		return associateList;
	}
}