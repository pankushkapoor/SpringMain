package com.cg.payroll.daoservices;

import java.util.ArrayList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.payroll.beans.Associate;

public interface AssociateDAO extends JpaRepository<Associate, Integer>{
	/*Associate save(Associate associate);
	Associate findOne(int associateId);
	Associate[] findAll();
	ArrayList<Associate> findAll();
	boolean update(Associate associate);*/
	
	
	//custom method so we'll have to keep it
	@Query("FROM Associate a WHERE a.yearlyInvestmentUnder80C=?1") 
	ArrayList<Associate> findFewAssociate(int yearlyInvestmentUnder80C); //@Param("associateList") 
}
